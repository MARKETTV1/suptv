#!/bin/sh
wget -q "http://127.0.0.1/web/servicelistreload?mode=1" -O /dev/null
wget -q "http://127.0.0.1/web/servicelistreload?mode=2" -O /dev/null